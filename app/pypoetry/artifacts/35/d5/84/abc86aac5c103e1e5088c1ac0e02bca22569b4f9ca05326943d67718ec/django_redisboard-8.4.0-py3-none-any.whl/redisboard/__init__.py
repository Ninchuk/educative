__version__ = '8.4.0'
default_app_config = 'redisboard.apps.RedisboardApp'
