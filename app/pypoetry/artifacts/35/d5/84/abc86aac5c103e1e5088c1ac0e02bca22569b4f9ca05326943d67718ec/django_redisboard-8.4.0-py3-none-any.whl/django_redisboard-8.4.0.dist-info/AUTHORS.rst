
Authors
=======

* Ionel Cristian Mărieș - http://blog.ionelmc.ro
* Areski Belaid - http://areskibelaid.com/
* Steve Kossouho - https://github.com/artscoop
* Rick van Hattem - http://w.wol.ph/
* Benjamin Wohlwend - https://github.com/piquadrat
* Trbs - https://github.com/trbs
* John Lau - https://github.com/jolks
* ??? - https://github.com/gabn88
* Erik Telepovský - https://github.com/eriktelepovsky
* Gilles Lavaux - https://github.com/gilav
* ??? - https://github.com/Rand01ph
* Alireza Amouzadeh - https://github.com/Alireza2n
