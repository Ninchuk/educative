from django.apps import AppConfig


class RedisboardApp(AppConfig):
    name = 'redisboard'
    default_auto_field = 'django.db.models.AutoField'
